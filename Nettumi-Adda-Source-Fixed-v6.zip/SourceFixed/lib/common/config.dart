/*
 *  Nettumi Adda - Bondhuder Sathe Adda
 *  Apps Configuration
*/

/* =============================== */
/* 🔑 Nettumi Adda Configuration 🔑       */
/* =============================== */

// Nettumi API Key & Secret
const String apiKey = "e00a5b6964e0ef2a04bc5840d445405568f2824b771870bc";
const String apiSecret = "c7036b6c0f5b401b1ef0aa04509cc21acee5323179b0c549913e4847b67b751d";

// Nettumi Website URL (Your website URL)
const String apiURL = "https://nettumi.com";

// Debugging Mode
const bool debugEnabled = false;

/* =============================== */
/* 🔔 OneSignal Configuration 🔔 */
/* =============================== */

// OneSignal App ID
const String oneSignalAppId = "e2159733-5895-4cf4-9348-3fc28cc57341";

/* =============================== */
/* 🛑 DON'T EDIT BELOW THIS LINE 🛑 */
/* =============================== */

// API Base URL
const String apiBase = "apis";
const String apiStack = "php";
const String apiBaseURL = "$apiURL/$apiBase/$apiStack";

// Audio/Video Call (Not implemented yet)
bool audioVideoCallEnabled = false;

// Social Login (Not implemented yet)
bool socialLoginEnabled = false;
