import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:auto_route/auto_route.dart';
import 'package:animate_do/animate_do.dart';
import '../../routes/router.gr.dart';

@RoutePage()
class SplashScreen extends StatefulWidget {
  static const routeName = '/splash';
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {
  late AnimationController _rotateController;
  late AnimationController _floatController;
  late AnimationController _glowController;
  late Animation<double> _floatAnim;
  late Animation<double> _glowAnim;

  @override
  void initState() {
    super.initState();

    _rotateController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 8),
    )..repeat();

    _floatController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat(reverse: true);

    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);

    _floatAnim = Tween<double>(begin: -12, end: 12).animate(
      CurvedAnimation(parent: _floatController, curve: Curves.easeInOut),
    );

    _glowAnim = Tween<double>(begin: 15, end: 40).animate(
      CurvedAnimation(parent: _glowController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _rotateController.dispose();
    _floatController.dispose();
    _glowController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Color(0xFF0D0D2B),
              Color(0xFF1A1A4E),
              Color(0xFF2D1B69),
              Color(0xFF0D0D2B),
            ],
            stops: [0.0, 0.3, 0.7, 1.0],
          ),
        ),
        child: Stack(
          children: [
            // ── Rotating background rings ──
            AnimatedBuilder(
              animation: _rotateController,
              builder: (_, __) {
                return Positioned(
                  top: size.height * 0.1,
                  left: size.width * 0.5 - 160,
                  child: Transform.rotate(
                    angle: _rotateController.value * 2 * math.pi,
                    child: Container(
                      width: 320,
                      height: 320,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: const Color(0xFF9B59B6).withOpacity(0.15),
                          width: 1,
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
            AnimatedBuilder(
              animation: _rotateController,
              builder: (_, __) {
                return Positioned(
                  top: size.height * 0.1 + 30,
                  left: size.width * 0.5 - 130,
                  child: Transform.rotate(
                    angle: -_rotateController.value * 2 * math.pi * 0.7,
                    child: Container(
                      width: 260,
                      height: 260,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: const Color(0xFF3498DB).withOpacity(0.2),
                          width: 1.5,
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),

            // ── Floating particles ──
            ...List.generate(8, (i) {
              final random = math.Random(i * 42);
              final left = random.nextDouble() * size.width;
              final top = random.nextDouble() * size.height * 0.6;
              final delay = random.nextDouble() * 2000;
              return Positioned(
                left: left,
                top: top,
                child: AnimatedBuilder(
                  animation: _floatController,
                  builder: (_, __) => Transform.translate(
                    offset: Offset(0, _floatAnim.value * (i.isEven ? 1 : -1)),
                    child: Container(
                      width: 4,
                      height: 4,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: [
                          const Color(0xFF9B59B6),
                          const Color(0xFF3498DB),
                          const Color(0xFFE74C3C),
                          const Color(0xFFF39C12),
                        ][i % 4].withOpacity(0.6),
                        boxShadow: [
                          BoxShadow(
                            color: [
                              const Color(0xFF9B59B6),
                              const Color(0xFF3498DB),
                              const Color(0xFFE74C3C),
                              const Color(0xFFF39C12),
                            ][i % 4].withOpacity(0.8),
                            blurRadius: 6,
                            spreadRadius: 2,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              );
            }),

            // ── Main content ──
            SafeArea(
              child: Column(
                children: [
                  const SizedBox(height: 60),

                  // 3D Logo
                  AnimatedBuilder(
                    animation: Listenable.merge([_floatController, _glowController]),
                    builder: (_, __) {
                      return Transform.translate(
                        offset: Offset(0, _floatAnim.value),
                        child: Container(
                          width: 200,
                          height: 200,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                color: const Color(0xFF9B59B6).withOpacity(0.5),
                                blurRadius: _glowAnim.value,
                                spreadRadius: _glowAnim.value * 0.3,
                              ),
                              BoxShadow(
                                color: const Color(0xFF3498DB).withOpacity(0.3),
                                blurRadius: _glowAnim.value * 1.5,
                                spreadRadius: _glowAnim.value * 0.1,
                              ),
                            ],
                          ),
                          child: FadeInDown(
                            duration: const Duration(milliseconds: 1000),
                            child: Transform(
                              transform: Matrix4.identity()
                                ..setEntry(3, 2, 0.001)
                                ..rotateX(0.05 * math.sin(_rotateController.value * 2 * math.pi))
                                ..rotateY(0.08 * math.sin(_rotateController.value * 2 * math.pi)),
                              alignment: Alignment.center,
                              child: ClipOval(
                                child: Image.asset(
                                  'assets/images/welcome_image.png',
                                  width: 200,
                                  height: 200,
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  ),

                  const SizedBox(height: 40),

                  // App name - Bangla
                  FadeInUp(
                    delay: const Duration(milliseconds: 300),
                    duration: const Duration(milliseconds: 800),
                    child: ShaderMask(
                      shaderCallback: (bounds) => const LinearGradient(
                        colors: [Color(0xFFE040FB), Color(0xFF00BCD4), Color(0xFFE040FB)],
                        stops: [0.0, 0.5, 1.0],
                      ).createShader(bounds),
                      child: const Text(
                        'নেত্তুমি আড্ডা',
                        style: TextStyle(
                          fontSize: 36,
                          fontWeight: FontWeight.w900,
                          color: Colors.white,
                          letterSpacing: 2,
                          shadows: [
                            Shadow(
                              color: Color(0xFF9B59B6),
                              blurRadius: 20,
                              offset: Offset(0, 4),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 6),

                  // App name - English
                  FadeInUp(
                    delay: const Duration(milliseconds: 500),
                    duration: const Duration(milliseconds: 800),
                    child: const Text(
                      'Nettumi Adda',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w500,
                        color: Colors.white60,
                        letterSpacing: 4,
                      ),
                    ),
                  ),

                  const SizedBox(height: 50),

                  // Tagline Banglish
                  FadeInLeft(
                    delay: const Duration(milliseconds: 700),
                    duration: const Duration(milliseconds: 900),
                    child: Container(
                      margin: const EdgeInsets.symmetric(horizontal: 30),
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        color: Colors.white.withOpacity(0.05),
                        border: Border.all(
                          color: const Color(0xFF9B59B6).withOpacity(0.3),
                          width: 1,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: const Color(0xFF9B59B6).withOpacity(0.1),
                            blurRadius: 20,
                            spreadRadius: 2,
                          ),
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Banglish line 1
                          _buildTagLine(
                            'Addai Mete Thako',
                            'আড্ডায় মেতে থাকো',
                            const Color(0xFFE040FB),
                            const Duration(milliseconds: 800),
                          ),
                          const SizedBox(height: 8),
                          // Banglish line 2
                          _buildTagLine(
                            'Bonduder Sathe',
                            'বন্ধুদের সাথে',
                            const Color(0xFF00BCD4),
                            const Duration(milliseconds: 1000),
                          ),
                          const SizedBox(height: 8),
                          // Banglish line 3
                          _buildTagLine(
                            'Kotha Hok Unmokto',
                            'কথা হোক উন্মুক্ত',
                            const Color(0xFFF39C12),
                            const Duration(milliseconds: 1200),
                          ),
                        ],
                      ),
                    ),
                  ),

                  const Spacer(),

                  // Start button
                  FadeInUp(
                    delay: const Duration(milliseconds: 1400),
                    duration: const Duration(milliseconds: 800),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 30),
                      child: _NeonButton(
                        onTap: () {
                          context.router.replaceAll([const SignInRoute()]);
                        },
                        label: 'শুরু করো  •  Start Chatting',
                      ),
                    ),
                  ),

                  const SizedBox(height: 40),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTagLine(String banglish, String bangla, Color color, Duration delay) {
    return FadeInRight(
      delay: delay,
      duration: const Duration(milliseconds: 600),
      child: Row(
        children: [
          Container(
            width: 3,
            height: 36,
            decoration: BoxDecoration(
              color: color,
              borderRadius: BorderRadius.circular(2),
              boxShadow: [
                BoxShadow(color: color.withOpacity(0.6), blurRadius: 8),
              ],
            ),
          ),
          const SizedBox(width: 12),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                banglish,
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                  color: color,
                  letterSpacing: 0.5,
                ),
              ),
              Text(
                bangla,
                style: const TextStyle(
                  fontSize: 12,
                  color: Colors.white54,
                  letterSpacing: 0.3,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// ── Neon animated button ──
class _NeonButton extends StatefulWidget {
  final VoidCallback onTap;
  final String label;
  const _NeonButton({required this.onTap, required this.label});

  @override
  State<_NeonButton> createState() => _NeonButtonState();
}

class _NeonButtonState extends State<_NeonButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _pulse;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(seconds: 2))
      ..repeat(reverse: true);
    _pulse = Tween<double>(begin: 0.85, end: 1.0).animate(
      CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _pulse,
      builder: (_, __) => GestureDetector(
        onTap: widget.onTap,
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 18),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            gradient: const LinearGradient(
              colors: [Color(0xFF9B59B6), Color(0xFF3498DB), Color(0xFF9B59B6)],
            ),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFF9B59B6).withOpacity(_pulse.value),
                blurRadius: 25 * _pulse.value,
                spreadRadius: 2 * _pulse.value,
              ),
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                widget.label,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 1,
                ),
              ),
              const SizedBox(width: 10),
              const Icon(Icons.arrow_forward_ios, color: Colors.white, size: 16),
            ],
          ),
        ),
      ),
    );
  }
}
