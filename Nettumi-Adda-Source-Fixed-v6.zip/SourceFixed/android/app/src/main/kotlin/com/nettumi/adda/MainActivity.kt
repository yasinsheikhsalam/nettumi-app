package com.nettumi.adda

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
