import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:easy_localization/easy_localization.dart';

import '../widgets/snackbar.dart';
import 'functions.dart';

class VoiceRecorder {
  static final VoiceRecorder _instance = VoiceRecorder._internal();
  factory VoiceRecorder() => _instance;
  VoiceRecorder._internal();

  static const MethodChannel _channel = MethodChannel('nettumi_adda/recorder');
  String? _fileName;
  String? _recordPath;
  bool _isRecording = false;

  bool get isRecording => _isRecording;

  Future<void> startRecording({
    required BuildContext context,
    required Function(bool isRecording) setRecordingState,
  }) async {
    if (_isRecording) return;
    final status = await Permission.microphone.request();
    if (!status.isGranted) {
      if (context.mounted) {
        ScaffoldMessenger.of(context)
          ..removeCurrentSnackBar()
          ..showSnackBar(snackBarError(tr('Microphone permission not granted')));
      }
      return;
    }
    try {
      final dir = await getTemporaryDirectory();
      _fileName = '${DateTime.now().millisecondsSinceEpoch}.m4a';
      _recordPath = '${dir.path}/$_fileName';
      await _channel.invokeMethod('startRecording', {'path': _recordPath});
      _isRecording = true;
      setRecordingState(true);
    } catch (e) {
      _isRecording = false;
      setRecordingState(false);
      if (context.mounted) {
        ScaffoldMessenger.of(context)
          ..removeCurrentSnackBar()
          ..showSnackBar(snackBarError(tr('Failed to start recording')));
      }
    }
  }

  Future<String?> stopRecording({
    required BuildContext context,
    required Function(bool isRecording) setRecordingState,
  }) async {
    if (!_isRecording || _recordPath == null) return null;
    try {
      await _channel.invokeMethod('stopRecording');
      _isRecording = false;
      setRecordingState(false);
      final response = await sendAPIRequest(
        'data/upload',
        method: 'UPLOAD',
        body: <String, String>{
          'type': 'audio',
          'handle': 'voice_notes',
          'multiple': 'false',
          'name': _fileName!,
          'guid': getGUID(),
        },
        files: [_recordPath!],
      );
      if (response['statusCode'] == 200) {
        return response['body']['data'];
      } else {
        if (context.mounted) {
          ScaffoldMessenger.of(context)
            ..removeCurrentSnackBar()
            ..showSnackBar(snackBarError(response['body']['message']));
        }
      }
    } catch (e) {
      _isRecording = false;
      setRecordingState(false);
      if (context.mounted) {
        ScaffoldMessenger.of(context)
          ..removeCurrentSnackBar()
          ..showSnackBar(snackBarError(tr('Failed to stop recording')));
      }
    }
    return null;
  }

  Future<void> dispose() async {
    if (_isRecording) {
      try { await _channel.invokeMethod('stopRecording'); } catch (_) {}
      _isRecording = false;
    }
  }
}
