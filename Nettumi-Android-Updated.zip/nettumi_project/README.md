# Nettumi Android App

Nettumi WebView Android App - https://nettumi.com

## Build করার নিয়ম (মোবাইল দিয়ে)

### ধাপ ১: GitHub এ Upload করুন
1. [github.com](https://github.com) এ Login করুন
2. নতুন **Private Repository** তৈরি করুন, নাম দিন: `nettumi-android`
3. এই zip এর সব ফাইল upload করুন (drag & drop)

### ধাপ ২: APK Build হবে Automatically
- Code push হলেই GitHub Actions automatically APK build করবে
- **Actions** tab এ গিয়ে build status দেখুন
- Build শেষ হলে **Artifacts** থেকে `Nettumi-Debug-APK` download করুন

### ⚙️ যা পরিবর্তন হয়েছে
- ✅ Website URL: `https://nettumi.com/`
- ✅ App নাম: `Nettumi`
- ✅ Package ID: `com.nettumi.app`
- ✅ সব resource files তৈরি করা হয়েছে
- ✅ GitHub Actions workflow যোগ করা হয়েছে

### 🔔 OneSignal (Push Notification) - Optional
Push notification চাইলে:
1. [onesignal.com](https://onesignal.com) এ ফ্রি account করুন
2. App ID পান
3. `SngineConfig.java` তে `Sngine_ONESIGNAL_APP_ID` এ ID বসান

### ❌ Firebase লাগবে না
এই project এ Firebase ব্যবহার করা হয়নি।
